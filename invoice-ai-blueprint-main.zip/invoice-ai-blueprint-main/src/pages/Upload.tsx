import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Upload as UploadIcon, FileText, ArrowLeft } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";

const Upload = () => {
  const [dragActive, setDragActive] = useState(false);
  const [separatePages, setSeparatePages] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      // Handle file upload logic here
      console.log("Files dropped:", e.dataTransfer.files);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      // Handle file upload logic here
      console.log("Files selected:", e.target.files);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4" />
              Volver
            </Link>
            <div className="flex items-center gap-2">
              <FileText className="w-6 h-6 text-primary" />
              <h1 className="text-xl font-semibold">Invoice AI</h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card className="p-8">
            <CardContent className="space-y-8">
              {/* Title */}
              <div className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <UploadIcon className="w-8 h-8 text-primary" />
                </div>
                <h2 className="text-2xl font-bold text-foreground mb-2">
                  Desde aquí puedes subir todos tus documentos
                </h2>
                <p className="text-muted-foreground">
                  Puede ser en formato pdf/jpg/png o desde un fichero zip/rar/7z que contenga varios archivos
                </p>
              </div>

              {/* Upload Area */}
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragActive 
                    ? "border-primary bg-primary/5" 
                    : "border-border hover:border-primary/50"
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <UploadIcon className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground mb-4">
                  Arrastra aquí sus ficheros o haga click para seleccionar ficheros desde carpeta
                </p>
                <input
                  type="file"
                  multiple
                  accept=".pdf,.jpg,.jpeg,.png,.zip,.rar,.7z"
                  onChange={handleFileSelect}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload">
                  <Button variant="outline" className="cursor-pointer">
                    Seleccionar archivos
                  </Button>
                </label>
              </div>

              {/* Form Fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Document Type */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">
                    Tipo de documento
                  </label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Factura de proveedor" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="supplier-invoice">Factura de proveedor</SelectItem>
                      <SelectItem value="customer-invoice">Factura de cliente</SelectItem>
                      <SelectItem value="receipt">Recibo</SelectItem>
                      <SelectItem value="expense">Gasto</SelectItem>
                      <SelectItem value="other">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Accounting Date */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">
                    Fecha contable
                  </label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Hoy" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="today">Hoy</SelectItem>
                      <SelectItem value="yesterday">Ayer</SelectItem>
                      <SelectItem value="this-week">Esta semana</SelectItem>
                      <SelectItem value="last-week">Semana pasada</SelectItem>
                      <SelectItem value="this-month">Este mes</SelectItem>
                      <SelectItem value="last-month">Mes pasado</SelectItem>
                      <SelectItem value="custom">Fecha personalizada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Additional Options */}
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="separate-pages" 
                    checked={separatePages}
                    onCheckedChange={(checked) => setSeparatePages(checked as boolean)}
                  />
                  <label 
                    htmlFor="separate-pages" 
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Separar páginas
                  </label>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">
                    Canal
                  </label>
                  <Select>
                    <SelectTrigger className="w-full md:w-48">
                      <SelectValue placeholder="Canal" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="web">Web</SelectItem>
                      <SelectItem value="mobile">Móvil</SelectItem>
                      <SelectItem value="scan">Escaneado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Submit Button */}
              <div className="flex justify-center pt-4">
                <Button size="lg" className="px-8">
                  Subir documentos
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Upload;