import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, Shield, Smartphone, BarChart3, Zap, Star } from "lucide-react";
import { Link } from "react-router-dom";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center max-w-4xl mx-auto">
          <Badge variant="secondary" className="mb-6">
            Trusted by 500+ Spanish Accounting Firms
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-foreground">
            Stop Losing Hours to Manual Invoice Entry
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            AI-powered invoice processing that syncs seamlessly with A3 systems - designed specifically for Spanish accounting firms. Reduce errors by 95% and save 15+ hours per week.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button size="lg" className="text-lg px-8 py-4" asChild>
              <Link to="/upload">Empezar</Link>
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-4">
              Watch Demo (2 min)
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            No credit card required • Setup in under 5 minutes • Cancel anytime
          </p>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="container mx-auto px-4 py-12 border-t border-border">
        <div className="text-center mb-8">
          <p className="text-muted-foreground mb-6">Trusted by leading Spanish accounting firms</p>
          <div className="flex justify-center items-center space-x-8 opacity-60">
            <div className="text-lg font-semibold">Deloitte España</div>
            <div className="text-lg font-semibold">KPMG</div>
            <div className="text-lg font-semibold">PwC España</div>
            <div className="text-lg font-semibold">Grant Thornton</div>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
          <div className="text-center">
            <div className="text-3xl font-bold text-primary mb-2">99.2%</div>
            <p className="text-muted-foreground">Invoice accuracy rate</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-primary mb-2">15+ hrs</div>
            <p className="text-muted-foreground">Saved per week</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-primary mb-2">500+</div>
            <p className="text-muted-foreground">Active users</p>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-8 text-foreground">
            Spanish Accountants Are Drowning in Manual Work
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <Card className="p-6">
              <CardContent>
                <h3 className="text-xl font-semibold mb-4 text-destructive">Manual Entry Errors Cost You</h3>
                <p className="text-muted-foreground">
                  Every typo, missed decimal, or misread field creates compliance risks and client trust issues that take hours to fix.
                </p>
              </CardContent>
            </Card>
            <Card className="p-6">
              <CardContent>
                <h3 className="text-xl font-semibold mb-4 text-destructive">Hours Lost Every Day</h3>
                <p className="text-muted-foreground">
                  Your team spends 3-5 hours daily on invoice data entry instead of high-value advisory work.
                </p>
              </CardContent>
            </Card>
            <Card className="p-6">
              <CardContent>
                <h3 className="text-xl font-semibold mb-4 text-destructive">A3 Integration Nightmares</h3>
                <p className="text-muted-foreground">
                  Switching between systems, manual data transfers, and version conflicts slow down your entire workflow.
                </p>
              </CardContent>
            </Card>
            <Card className="p-6">
              <CardContent>
                <h3 className="text-xl font-semibold mb-4 text-destructive">Spanish Compliance Pressure</h3>
                <p className="text-muted-foreground">
                  Meeting AEAT requirements and Spanish tax regulations manually increases stress and error risk.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="container mx-auto px-4 py-20 bg-accent/50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-8 text-foreground">
            AI That Actually Understands Spanish Invoices
          </h2>
          <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            Our AI reads Spanish invoices like a human expert, extracts data with 99.2% accuracy, and syncs directly to your A3 system - all in seconds.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="p-6">
              <CardContent>
                <CheckCircle className="w-12 h-12 text-primary mb-4 mx-auto" />
                <h3 className="text-xl font-semibold mb-4">99.2% Accuracy Guaranteed</h3>
                <p className="text-muted-foreground">
                  Advanced AI trained on millions of Spanish invoices ensures perfect data extraction every time.
                </p>
              </CardContent>
            </Card>
            <Card className="p-6">
              <CardContent>
                <Clock className="w-12 h-12 text-primary mb-4 mx-auto" />
                <h3 className="text-xl font-semibold mb-4">Save 15+ Hours Weekly</h3>
                <p className="text-muted-foreground">
                  Process hundreds of invoices in minutes instead of hours, freeing your team for strategic work.
                </p>
              </CardContent>
            </Card>
            <Card className="p-6">
              <CardContent>
                <Shield className="w-12 h-12 text-primary mb-4 mx-auto" />
                <h3 className="text-xl font-semibold mb-4">Seamless A3 Integration</h3>
                <p className="text-muted-foreground">
                  Direct sync with Wolters Kluwer A3 systems - no manual transfers or duplicate entries needed.
                </p>
              </CardContent>
            </Card>
            <Card className="p-6">
              <CardContent>
                <BarChart3 className="w-12 h-12 text-primary mb-4 mx-auto" />
                <h3 className="text-xl font-semibold mb-4">Spanish Regulation Ready</h3>
                <p className="text-muted-foreground">
                  Built for AEAT compliance with automatic Spanish tax code recognition and validation.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-12 text-foreground">
            From Invoice to A3 in 3 Simple Steps
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-2xl font-bold mx-auto mb-4">
                1
              </div>
              <h3 className="text-xl font-semibold mb-4">Snap & Upload</h3>
              <p className="text-muted-foreground">
                Take a photo or upload your invoice from any device. Our mobile app makes it instant.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-2xl font-bold mx-auto mb-4">
                2
              </div>
              <h3 className="text-xl font-semibold mb-4">AI Processing</h3>
              <p className="text-muted-foreground">
                Our AI extracts all data in seconds - vendor info, amounts, tax codes, dates - with 99.2% accuracy.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-2xl font-bold mx-auto mb-4">
                3
              </div>
              <h3 className="text-xl font-semibold mb-4">Auto-Sync to A3</h3>
              <p className="text-muted-foreground">
                Data flows directly into your A3 system, formatted perfectly for Spanish accounting standards.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20 bg-accent/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-center text-foreground">
            Everything You Need for Modern Invoice Processing
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <Smartphone className="w-8 h-8 text-primary mb-2" />
                <CardTitle>Smart OCR for Spanish Invoices</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Advanced optical character recognition trained specifically on Spanish invoice formats and terminology.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Zap className="w-8 h-8 text-primary mb-2" />
                <CardTitle>Native A3 Integration</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Direct connection with Wolters Kluwer A3 systems - no third-party tools or manual exports needed.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Smartphone className="w-8 h-8 text-primary mb-2" />
                <CardTitle>Mobile Capture</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Process invoices on-the-go with our mobile app. Perfect for client visits and remote work.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <BarChart3 className="w-8 h-8 text-primary mb-2" />
                <CardTitle>Compliance Dashboard</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Real-time monitoring of Spanish tax compliance with automatic AEAT requirement validation.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Shield className="w-8 h-8 text-primary mb-2" />
                <CardTitle>Error Detection</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  AI automatically flags potential issues before they reach your A3 system, preventing costly mistakes.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Clock className="w-8 h-8 text-primary mb-2" />
                <CardTitle>Bulk Processing</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Upload and process hundreds of invoices simultaneously during busy periods or month-end closing.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-12 text-foreground">
            Trusted by Spanish Accounting Professionals
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <Card className="p-6">
              <CardContent>
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-4 italic">
                  "This AI tool has transformed our practice. We're processing 3x more invoices with half the errors. The A3 integration is flawless."
                </p>
                <div className="text-left">
                  <p className="font-semibold">María González</p>
                  <p className="text-sm text-muted-foreground">Senior Partner, González & Associates</p>
                </div>
              </CardContent>
            </Card>
            <Card className="p-6">
              <CardContent>
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-4 italic">
                  "Finally, an AI solution that understands Spanish invoices perfectly. Our team saves 20 hours per week and clients love the faster turnaround."
                </p>
                <div className="text-left">
                  <p className="font-semibold">Carlos Ruiz</p>
                  <p className="text-sm text-muted-foreground">Managing Director, Ruiz Accounting Services</p>
                </div>
              </CardContent>
            </Card>
          </div>
          <div className="text-center">
            <h3 className="text-2xl font-semibold mb-4">Case Study: Serrano & Partners</h3>
            <div className="grid grid-cols-3 gap-8 max-w-2xl mx-auto">
              <div>
                <div className="text-3xl font-bold text-primary mb-2">89%</div>
                <p className="text-muted-foreground">Time saved on invoice processing</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-primary mb-2">95%</div>
                <p className="text-muted-foreground">Reduction in data entry errors</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-primary mb-2">€15k</div>
                <p className="text-muted-foreground">Monthly savings in labor costs</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="container mx-auto px-4 py-20 bg-primary text-primary-foreground">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">
            Ready to Transform Your Invoice Processing?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Join 500+ Spanish accounting firms already saving 15+ hours per week with AI-powered invoice processing.
          </p>
           <Button size="lg" variant="secondary" className="text-lg px-8 py-4 mb-6" asChild>
             <Link to="/upload">Empezar</Link>
           </Button>
          <div className="text-sm opacity-80">
            <p>✓ No credit card required ✓ Setup in 5 minutes ✓ Cancel anytime</p>
            <p>✓ 30-day money-back guarantee ✓ Free A3 integration setup</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-accent/30 py-12">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">Invoice AI</h3>
            <p className="text-muted-foreground mb-6">
              AI-powered invoice processing for Spanish accounting firms
            </p>
            <div className="flex justify-center space-x-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-foreground">Privacy Policy</a>
              <a href="#" className="hover:text-foreground">Terms of Service</a>
              <a href="#" className="hover:text-foreground">Contact Support</a>
            </div>
            <p className="text-xs text-muted-foreground mt-6">
              © 2024 Invoice AI. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
